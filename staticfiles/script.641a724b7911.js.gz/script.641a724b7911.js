
var messages = document.getElementById("messages_container");

setTimeout(function(){
messages.style.display = "none";
},3000);

function CloseMsgBox() {
messages.style.display = "none";
}